import { useState, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Search, Loader2, AlertCircle, ChevronRight, ImageIcon, X } from 'lucide-react';
import { motion } from 'motion/react';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const SYSTEM_INSTRUCTION_PROJECT = `You are a crypto research assistant designed to turn messy information into clear, structured insights.

Your job is to analyze a crypto project based on any input (name, description, or text) and produce a concise, high-signal breakdown.

Always respond in this exact structure using Markdown:

### 1. Overview
Explain the project in simple terms (2-3 sentences max).

### 2. Core Idea
What problem is this project trying to solve?

### 3. Strengths
- bullet points (max 4)
- focus on real advantages, not hype

### 4. Risks / Weaknesses
- bullet points (max 4)
- include realistic risks (tokenomics, competition, adoption, etc.)

### 5. Use Case
Who actually needs this? Be specific.

### 6. Market Position
Is this early, crowded, or late? Brief explanation.

### 7. Verdict
Give a clear, honest conclusion in 1-2 sentences.

Rules:
- No hype, no marketing language
- Be direct and analytical
- If information is limited, say "insufficient data" instead of guessing
- Keep it concise but insightful
- Do not add conversational filler before or after the structure. Use the headings exactly as written.`;

const SYSTEM_INSTRUCTION_MARKET = `You are a crypto research assistant designed to turn messy information into clear, structured insights.

Your job is to analyze a crypto project based on any input (name, description, or text) and produce a concise, high-signal breakdown.

Always respond in this exact structure using Markdown:

### 1. Overview  
Explain the project in simple terms (2-3 sentences max).

### 2. Core Idea  
What problem is this project trying to solve?

### 3. Strengths  
- bullet points (max 4)

### 4. Risks / Weaknesses  
- bullet points (max 4)

### 5. Use Case  
Who actually needs this? Be specific.

### 6. Market Position  
Is this early, crowded, or late? Brief explanation.

### 7. Verdict  
Give a clear, honest conclusion in 1-2 sentences.

--- ADDITIONAL FEATURE: CHART INSIGHT ---

If the user input contains price action, chart description, or market movement (such as price increase, decrease, volume, trend, or volatility), then append an additional section at the end.

Do NOT modify or remove the existing structure above.

Add this section only when relevant:

### 8. AI Market Insight  
- Market Context: brief description  
- Price Action: trend, breakout, etc  
- Volume Insight: if available  
- Scenarios:
  - Bullish case  
  - Bearish case  
- Risk Level: Low / Medium / High  
- Conclusion: short summary  

Rules:
- No hype, no marketing language
- Be direct and analytical
- If information is limited, say "insufficient data"
- Only add section 8 if relevant
- If no chart context → skip section 8
- Do not repeat previous sections
- Keep concise and analytical
- Use the headings exactly as written.`;

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { 
    opacity: 1, 
    transition: { 
      staggerChildren: 0.1,
      delayChildren: 0.2
    } 
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 15 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] } }
};

const markdownComponents: any = {
  h3: ({ node, ...props }: any) => <motion.h3 variants={itemVariants} {...props} />,
  p: ({ node, ...props }: any) => <motion.p variants={itemVariants} {...props} />,
  ul: ({ node, ...props }: any) => <motion.ul variants={itemVariants} {...props} />
};

export default function App() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<'project' | 'market'>('project');
  const [image, setImage] = useState<{ url: string; base64: string; mimeType: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      setImage({ url: URL.createObjectURL(file), base64, mimeType: file.type });
    };
    reader.readAsDataURL(file);
  };

  const removeImage = () => {
    setImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAnalyze = async () => {
    if (!input.trim() && !image) return;

    setLoading(true);
    setError(null);

    try {
      let contents: any = input;
      if (image && mode === 'market') {
        contents = [
          {
            inlineData: {
              data: image.base64,
              mimeType: image.mimeType
            }
          },
          input || "Analyze this chart"
        ];
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents,
        config: {
          systemInstruction: mode === 'project' ? SYSTEM_INSTRUCTION_PROJECT : SYSTEM_INSTRUCTION_MARKET,
        },
      });

      if (response.text) {
        setResult(response.text);
      } else {
        setError('No analytical result returned from the model.');
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred during analysis.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020204] text-slate-300 font-sans selection:bg-indigo-500/30 relative overflow-x-hidden">
      {/* Immersive Background */}
      <div className="fixed inset-0 z-0 pointer-events-none flex items-center justify-center">
        <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full bg-indigo-600/20 mix-blend-screen blur-[120px] animate-blob"></div>
        <div className="absolute top-[20%] right-[-10%] w-[40vw] h-[40vw] rounded-full bg-purple-600/20 mix-blend-screen blur-[120px] animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-[-10%] left-[20%] w-[60vw] h-[60vw] rounded-full bg-blue-600/10 mix-blend-screen blur-[150px] animate-blob animation-delay-4000"></div>
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCI+CjxwYXRoIGQ9Ik0wIDBoNDB2NDBIMHoiIGZpbGw9Im5vbmUiLz4KPHBhdGggZD0iTTAgNDBMMDAgMEw0MCAwIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4wMykiIHN0cm9rZS13aWR0aD0iMSIvPgo8L3N2Zz4=')] opacity-50 bg-repeat mix-blend-overlay [mask-image:linear-gradient(to_bottom,transparent,black_10%,black_90%,transparent)]"></div>
      </div>

      <header className="border-b border-white/5 bg-[#020204]/60 p-6 flex items-center justify-between sticky top-0 z-20 backdrop-blur-2xl shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-indigo-400 border border-indigo-500/30 bg-indigo-500/10 shadow-[0_0_20px_rgba(99,102,241,0.3)] backdrop-blur-md relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <Search size={18} className="relative z-10" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-200 to-purple-300 drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">Crypto Sight</h1>
            <p className="text-[10px] uppercase tracking-widest font-bold text-indigo-500/80 mt-0.5 drop-shadow-[0_0_5px_rgba(99,102,241,0.5)]">Signal from the Noise</p>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
        {/* Input Panel */}
        <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-32 w-full">
          <div className="bg-[#0a0a0c]/80 border border-white/5 rounded-3xl p-6 shadow-2xl backdrop-blur-xl relative group">
            <div className="absolute top-0 left-10 right-10 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent transition-opacity duration-500 opacity-50 group-hover:opacity-100"></div>
            
            <div className="flex items-center gap-1 mb-6 p-1 bg-white/5 rounded-xl border border-white/10 shadow-inner">
              <div className="relative flex-1 group/tooltip">
                <button
                  onClick={() => setMode('project')}
                  className={`w-full py-2 px-3 text-xs font-bold uppercase tracking-wider rounded-lg transition-all ${
                    mode === 'project'
                      ? 'bg-indigo-500/20 text-indigo-300 shadow-[0_0_15px_rgba(99,102,241,0.3)] border border-indigo-500/30'
                      : 'text-slate-500 hover:text-slate-300 hover:bg-white/5 border border-transparent'
                  }`}
                >
                  Project Focus
                </button>
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 px-3 py-2 bg-[#020204]/95 border border-white/10 rounded-lg text-xs text-slate-300 font-normal normal-case whitespace-nowrap opacity-0 pointer-events-none group-hover/tooltip:opacity-100 transition-opacity z-50 shadow-[0_0_20px_rgba(0,0,0,0.8)] backdrop-blur-xl">
                  Analyzes project fundamentals, utility, and market fit.
                </div>
              </div>

              <div className="relative flex-1 group/tooltip">
                <button
                  onClick={() => setMode('market')}
                  className={`w-full py-2 px-3 text-xs font-bold uppercase tracking-wider rounded-lg transition-all ${
                    mode === 'market'
                      ? 'bg-purple-500/20 text-purple-300 shadow-[0_0_15px_rgba(168,85,247,0.3)] border border-purple-500/30'
                      : 'text-slate-500 hover:text-slate-300 hover:bg-white/5 border border-transparent'
                  }`}
                >
                  Market Insight
                </button>
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 px-3 py-2 bg-[#020204]/95 border border-white/10 rounded-lg text-xs text-slate-300 font-normal normal-case whitespace-nowrap opacity-0 pointer-events-none group-hover/tooltip:opacity-100 transition-opacity z-50 shadow-[0_0_20px_rgba(0,0,0,0.8)] backdrop-blur-xl">
                  Analyzes price action, charts, and market trends.
                </div>
              </div>
            </div>

            <h2 className="text-[11px] font-bold tracking-widest uppercase text-indigo-400 mb-5 flex items-center gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.8)]"></div>
              Input Context
            </h2>
            <div className="space-y-5">
              <label htmlFor="crypto-input" className="block text-[13.5px] text-slate-400 leading-relaxed">
                {mode === 'project' 
                  ? 'Paste a website link, whitepaper excerpt, or just type the name of a crypto project out loud.'
                  : 'Paste price action data, chart descriptions, or recent market movements along with project details.'}
              </label>
              <textarea
                id="crypto-input"
                className="w-full h-44 bg-black/40 border border-white/10 rounded-2xl p-5 text-slate-200 focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all resize-none font-mono text-sm placeholder:text-slate-600 shadow-inner"
                placeholder={mode === 'project' 
                  ? "e.g. Berachain - a high-performance EVM-compatible blockchain built on Proof-of-Liquidity consensus..."
                  : "e.g. AVAX has been breaking out of a 2-month downtrend on high volume. Project focuses on subnets..."}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                    handleAnalyze();
                  }
                }}
              />
              
              {mode === 'market' && (
                <div className="flex items-center mt-2">
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    ref={fileInputRef} 
                    onChange={handleImageUpload} 
                  />
                  {!image ? (
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      title="Add Chart Screenshot"
                      className="flex items-center justify-center w-10 h-10 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-purple-300 transition-colors group/imgbtn relative"
                    >
                      <ImageIcon size={18} className="group-hover/imgbtn:scale-110 transition-transform" />
                    </button>
                  ) : (
                    <div className="relative group/image">
                      <img src={image.url} alt="Uploaded chart" className="h-10 w-auto min-w-[40px] rounded-xl border border-purple-500/30 object-cover" />
                      <button
                        type="button"
                        onClick={removeImage}
                        className="absolute -top-2 -right-2 bg-red-500 hover:bg-red-600 text-white rounded-full p-1 opacity-0 group-hover/image:opacity-100 transition-opacity shadow-md"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  )}
                </div>
              )}

              <button
                onClick={handleAnalyze}
                disabled={loading || (!input.trim() && !image)}
                className="relative w-full bg-[#111116] border border-white/10 group py-4 px-4 rounded-xl font-medium transition-all focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden shadow-[0_0_20px_rgba(0,0,0,0.5)]"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 opacity-80 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute inset-x-0 top-0 h-px w-full bg-gradient-to-r from-transparent via-white/50 to-transparent mix-blend-overlay"></div>
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 shadow-[inset_0_0_20px_rgba(255,255,255,0.3)] transition-opacity duration-500"></div>
                <div className="relative flex items-center justify-center gap-2 text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.5)] text-[15px] tracking-wide">
                  {loading ? (
                    <>
                      <Loader2 size={18} className="animate-spin text-indigo-200" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      Synthesize Insight
                      <ChevronRight size={18} className="text-indigo-200 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </div>
              </button>
              <div className="text-center text-xs text-slate-500 font-mono mt-4 flex items-center justify-center gap-2">
                <span>Press</span> <kbd className="bg-white/5 text-slate-400 px-1.5 py-0.5 rounded border border-white/10 text-[10px] font-semibold">Cmd</kbd> <span>+</span> <kbd className="bg-white/5 text-slate-400 px-1.5 py-0.5 rounded border border-white/10 text-[10px] font-semibold">Enter</kbd>
              </div>
            </div>
          </div>
        </div>

        {/* Output Panel */}
        <div className="lg:col-span-7 w-full pb-20">
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-5 rounded-2xl flex items-start gap-4 mb-6 backdrop-blur-md">
              <AlertCircle size={22} className="shrink-0 mt-0.5 text-red-500" />
              <div className="text-sm font-medium leading-relaxed">{error}</div>
            </div>
          )}

          {!result && !loading && !error && (
            <div className="h-full min-h-[450px] flex flex-col items-center justify-center border border-dashed border-white/10 rounded-3xl p-8 text-center bg-black/20 backdrop-blur-sm relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-indigo-900/10 pointer-events-none group-hover:bg-indigo-900/20 transition-colors duration-1000"></div>
              
              <div className="relative w-40 h-40 mb-10 float-anim">
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full blur-[50px] opacity-20 animate-pulse"></div>
                <svg viewBox="0 0 200 200" className="w-full h-full relative z-10 drop-shadow-[0_0_20px_rgba(168,85,247,0.6)]">
                  <defs>
                    <linearGradient id="neon" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#818cf8" />
                      <stop offset="50%" stopColor="#c084fc" />
                      <stop offset="100%" stopColor="#e879f9" />
                    </linearGradient>
                  </defs>
                  {/* Outer Ring */}
                  <circle cx="100" cy="100" r="90" fill="none" stroke="url(#neon)" strokeWidth="1" strokeDasharray="4 6" className="origin-center animate-[spin_20s_linear_infinite]" />
                  {/* Inner Ring */}
                  <circle cx="100" cy="100" r="70" fill="none" stroke="url(#neon)" strokeWidth="2" strokeDasharray="20 10" className="origin-center animate-[spin_15s_linear_infinite_reverse]" />
                  {/* Center Crystal */}
                  <path d="M100 20 L130 100 L100 180 L70 100 Z" fill="none" stroke="url(#neon)" strokeWidth="2" className="animate-[pulse_3s_ease-in-out_infinite]" />
                  <path d="M100 20 L130 100 L70 100 Z" fill="rgba(192,132,252,0.15)" />
                  <path d="M100 180 L130 100 L70 100 Z" fill="rgba(129,140,248,0.15)" />
                  <circle cx="100" cy="100" r="8" fill="#fff" className="drop-shadow-[0_0_15px_#fff]" />
                </svg>
              </div>

              <h3 className="text-[17px] text-slate-200 font-medium mb-3 relative z-10 drop-shadow-md">Awaiting target parameters</h3>
              <p className="text-[14px] max-w-sm text-slate-400 relative z-10 leading-relaxed font-mono">
                Provide project details on the left to initiate unstructured data synthesis and intelligence extraction.
              </p>
            </div>
          )}

          {loading && (
            <div className="h-full min-h-[450px] flex flex-col items-center justify-center border border-indigo-500/20 rounded-3xl p-8 text-center bg-[#0a0a0c]/80 shadow-[0_0_50px_rgba(99,102,241,0.15)] overflow-hidden relative backdrop-blur-xl">
              <div className="absolute inset-0 bg-indigo-500/5 animate-pulse"></div>
              <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-indigo-400 to-transparent opacity-70 animate-pulse"></div>
              <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-purple-400 to-transparent opacity-70 animate-pulse"></div>
              
              <div className="relative mb-8 float-anim">
                <div className="absolute inset-0 bg-indigo-500 blur-[40px] opacity-40 rounded-full animate-pulse"></div>
                <Loader2 size={48} className="text-indigo-400 animate-spin relative z-10 filter drop-shadow-[0_0_15px_rgba(99,102,241,1)]" />
              </div>

              <h3 className="text-[18px] text-white font-medium mb-3 relative z-10 tracking-tight drop-shadow-lg">Running Synthesis</h3>
              <p className="text-[14px] text-indigo-300 max-w-sm relative z-10 font-mono tracking-tight animate-pulse">
                Parsing tokenomics, architecture, and market position...
              </p>
            </div>
          )}

          {result && !loading && (
            <div className="bg-[#0a0a0c]/80 border border-white/5 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-xl relative animate-in fade-in slide-in-from-bottom-8 duration-700">
               <div className="absolute top-0 left-20 right-20 h-[1px] bg-gradient-to-r from-transparent via-purple-500/30 to-transparent"></div>
              
              <div className="flex items-center justify-between mb-8 pb-6 border-b border-white/5">
                 <h2 className="text-[11px] font-bold tracking-widest uppercase text-slate-500 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.8)]"></div>
                    Intelligence Report
                 </h2>
                 <span className="bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-3 py-1.5 text-[10px] rounded-full font-bold uppercase tracking-widest shadow-[0_0_15px_rgba(99,102,241,0.15)] flex items-center gap-1.5">
                    <span className="w-1 h-1 rounded-full bg-indigo-400 animate-pulse"></span>
                    Ready
                 </span>
              </div>
              <motion.div 
                className="prose-custom"
                initial="hidden"
                animate="visible"
                variants={containerVariants}
              >
                <ReactMarkdown 
                  remarkPlugins={[remarkGfm]}
                  components={markdownComponents}
                >
                  {result}
                </ReactMarkdown>
              </motion.div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
